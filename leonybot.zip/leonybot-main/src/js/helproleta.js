const helproleta = `Roleta russa consiste em escolhe um membro aleatório do grupo e de acordo com a dificuldade, o membro escolhido sofrerá as consequências.
É bem fácil jogar, basta apenas dar o comando que começa em automático. Olhe abaixo as consequências de cada dificuldade

roletarussapac - não faz nada, apenas diversão
roletarussapac - bane o membro escolhido
roletarussamed - bane e bloqueia o membro escolhido
roletarussahard - bane, bloqueia e trava o membro escolhido

Obs: os efeitos são reversíveis, para desbloquear o membro basta apenas dar unblock (número sem espaço, traço ou +)`

exports.helproleta = helproleta